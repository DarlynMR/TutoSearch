package com.rd.dmmr.tutosearch;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Tutorias extends AppCompatActivity implements View.OnClickListener {

    RecyclerView RCAbajo;
    private TutoriasAdapter tutoriasAdapter;
    private FirebaseDatabase FDatabase;
    private DatabaseReference DBReference;

    Button btnBuscar;

    private List<ModelTutorias> mListTutoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorias);

        mListTutoria= new ArrayList<>();

        btnBuscar= (Button) findViewById(R.id.btnBuscar);

        FDatabase= FirebaseDatabase.getInstance();
        DBReference= FDatabase.getReference("UCATECI").child("Tutorias");


        RCAbajo= (RecyclerView) findViewById(R.id.RCAbajo);
        RCAbajo.setHasFixedSize(true);

        LinearLayoutManager layoutManager= new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);

        RCAbajo.setLayoutManager(layoutManager);

       //CrearTTutorias();

       tutoriasAdapter= new TutoriasAdapter(mListTutoria);

        RCAbajo.setAdapter(tutoriasAdapter);

        btnBuscar.setOnClickListener(this);



        upTutorias();
    }





    @Override
    public boolean onContextItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case 0:
                goDetalles(item.getGroupId());

                break;

            case 1:

                break;

        }

        Log.i("probando", "probando"+item.getGroupId());

        return super.onContextItemSelected(item);


    }


    private void upTutorias(){

        DBReference.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                //mListTutoria.add(dataSnapshot.getValue(ModelTutorias.class));/
                Log.i("LLEGANDO",dataSnapshot.toString());
                Log.i("LLEGANDO",dataSnapshot.getKey());

                String Materia, idProf, idTuto, imgTuto, Titulo, Descripcion, Profesor, Fecha, HoraI, HoraF,  Lugar;


                        imgTuto=dataSnapshot.child("Imagen").getValue().toString();
                        Titulo= dataSnapshot.child("Titulo").getValue().toString();
                        Descripcion= dataSnapshot.child("Descripción").getValue().toString();
                        Profesor= dataSnapshot.child("Profesor").getValue().toString();
                        Fecha= dataSnapshot.child("Fecha").getValue().toString();
                        HoraI= dataSnapshot.child("Hora inicial").getValue().toString();
                        HoraF= dataSnapshot.child("Hora final").getValue().toString();
                        Lugar= dataSnapshot.child("Lugar").getValue().toString();
                        idProf= dataSnapshot.child("UIDProfesor").getValue().toString();
                        Materia= dataSnapshot.child("Materia").getValue().toString();
                        idTuto= dataSnapshot.getKey();

                mListTutoria.add(new ModelTutorias(idTuto,idProf,imgTuto,Materia,Titulo,Descripcion,Profesor,Fecha,HoraI+" - "+HoraF,Lugar,""));




                tutoriasAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                ModelTutorias modelTutorias=dataSnapshot.getValue(ModelTutorias.class);

                Log.i("CAMBIANDO",dataSnapshot.toString()+" "+s);

                String Materia, idProf, idTuto, imgTuto, Titulo, Descripcion, Profesor, Fecha, HoraI, HoraF,  Lugar;
                int index=-1;



                imgTuto=dataSnapshot.child("Imagen").getValue().toString();
                Titulo= dataSnapshot.child("Titulo").getValue().toString();
                Descripcion= dataSnapshot.child("Descripción").getValue().toString();
                Profesor= dataSnapshot.child("Profesor").getValue().toString();
                Fecha= dataSnapshot.child("Fecha").getValue().toString();
                HoraI= dataSnapshot.child("Hora inicial").getValue().toString();
                HoraF= dataSnapshot.child("Hora final").getValue().toString();
                Lugar= dataSnapshot.child("Lugar").getValue().toString();
                idProf= dataSnapshot.child("UIDProfesor").getValue().toString();
                Materia= dataSnapshot.child("Materia").getValue().toString();
                idTuto= dataSnapshot.getKey();

                        index= getRCIndex(idTuto);

                        mListTutoria.set(index, new ModelTutorias(idTuto,idProf,imgTuto,Materia,Titulo,Descripcion,Profesor,Fecha,HoraI+" - "+HoraF,Lugar,""));
                        tutoriasAdapter.notifyItemChanged(index);






            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

                Log.i("Remover","Optimus");
                Log.i("Remover",dataSnapshot.toString());

                int index=-1;
                index= getRCIndex(dataSnapshot.getKey());

                mListTutoria.remove(index);
                tutoriasAdapter.notifyItemRemoved(index);
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void goDetalles(Integer pos){


        String palabra;

        Intent detalles = new Intent(Tutorias.this,DetallesTutorias.class);
        detalles.putExtra("idTuto",mListTutoria.get(pos).idTuto);
        Log.i("Prueba",mListTutoria.get(pos).idTuto+" "+pos);
        detalles.putExtra("Materia",mListTutoria.get(pos).materias);
        detalles.putExtra("idProf",mListTutoria.get(pos).idProf);
        detalles.putExtra("imgTuto",mListTutoria.get(pos).foto);
        detalles.putExtra("Titulo", mListTutoria.get(pos).titulo);
        detalles.putExtra("Descripcion",mListTutoria.get(pos).descripcion);
        detalles.putExtra("Profesor",mListTutoria.get(pos).profesores);
        detalles.putExtra("Fecha",mListTutoria.get(pos).fecha);
        detalles.putExtra("Hora",mListTutoria.get(pos).hora);
        detalles.putExtra("Lugar",mListTutoria.get(pos).lugar);


        startActivity(detalles);
    }

    public void limpiarRC() {
        mListTutoria.clear();
        tutoriasAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view) {
        if (view==btnBuscar){
            limpiarRC();
        }
    }



    private int getRCIndex(String iTuto){

        int index= -1;
        for(int i =0; i< mListTutoria.size(); i++){
            if(mListTutoria.get(i).idTuto.equals(iTuto)){
                Log.i("IndexNO",mListTutoria.get(i).idTuto+"="+iTuto);
                index=i;
                break;
            }
        }

        Log.i("IndexNO",""+index);
        return index;

    }
}
